package Enumerators;

public enum TipoTecnico {

}

package Enumerators;

public enum TurnoTecnico {

}

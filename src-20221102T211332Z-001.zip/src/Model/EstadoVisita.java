package Model;

public enum EstadoVisita {

}

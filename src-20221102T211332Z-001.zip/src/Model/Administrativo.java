package Model;

public class Administrativo {

}

package Model;

public class Tecnico {

}

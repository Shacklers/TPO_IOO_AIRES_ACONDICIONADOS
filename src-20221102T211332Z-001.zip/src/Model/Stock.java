package Model;

public class Stock {

}

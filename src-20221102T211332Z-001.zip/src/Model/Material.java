package Model;

public class Material {

}

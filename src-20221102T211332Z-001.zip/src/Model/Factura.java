package Model;

public class Factura {

}

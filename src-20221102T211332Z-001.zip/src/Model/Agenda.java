package Model;

public class Agenda {

}

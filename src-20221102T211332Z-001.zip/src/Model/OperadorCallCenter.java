package Model;

public class OperadorCallCenter {

}
